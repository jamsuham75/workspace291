//MySQL + Node.js 접속 코드
// var mysql = require('mysql');
// var conn = mysql.createConnection({
//     host : 'localhost',
//     user : 'root',
//     password : '123456',
//     database : 'book_db',
//     port : 3307
// });

// conn.connect();
let mydb;
//MongoDB + Node.js 접속 코드
const mongoClient = require('mongodb').MongoClient;
const url = '';
mongoClient.connect(url)
.then(client=>{
    console.log('몽고DB 접속 성공');

    mydb = client.db('myboard');

    app.listen(8081, function(){
        console.log('포트 8081으로 서버 대기중...');
    });
})
.catch(err=>{
    console.log(err);
})




const express = require('express');
const app = express();

//0-1024, 65535


app.get('/book', function(req, res){
    res.send('도서 목록 관련 페이지입니다.');
})

app.get('/list', function(req, res){
    // conn.query("select * from booklist", function(err, rows, field){
    //     if(err) throw err;
    //     console.log(rows);
    // });
    mydb.collection('post').find().toArray().then(result=>{
        console.log(result);
    })
})

//홈입니다.
app.get('/', function(req, res){
    // res.send(
    //     '<html>\
    //      <body>\
    //         <h1>홈입니다.</h1>\
    //         <marquee>트럼프님. 반갑습니다.</marquee>\
    //     </body>\
    //     </html>\
    //     ');
    

    res.sendFile(__dirname + '/index.html');
})

app.get('/enter', function(req, res){
    res.sendFile(__dirname + '/enter.html');
})
